import { Component } from '@angular/core';

@Component({
  selector: 'app-senati',
  standalone: true,
  imports: [],
  templateUrl: './senati.component.html',
  styleUrl: './senati.component.css'
})
export class SenatiComponent {

}
