import { Component } from '@angular/core';

@Component({
  selector: 'app-user-delete',
  standalone: true,
  imports: [],
  templateUrl: './user-delete.component.html',
  styleUrl: './user-delete.component.css'
})
export class UserDeleteComponent {

}
