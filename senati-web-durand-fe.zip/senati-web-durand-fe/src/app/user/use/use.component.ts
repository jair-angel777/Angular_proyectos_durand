import { Component } from '@angular/core';

@Component({
  selector: 'app-use',
  standalone: true,
  imports: [],
  templateUrl: './use.component.html',
  styleUrl: './use.component.css'
})
export class UseComponent {

}
