import { Component } from '@angular/core';

@Component({
  selector: 'app-user-update',
  standalone: true,
  imports: [],
  templateUrl: './user-update.component.html',
  styleUrl: './user-update.component.css'
})
export class UserUpdateComponent {

}
